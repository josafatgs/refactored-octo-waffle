
function Navbar() {
  return (
    <div className="">
        <div className="grid place-content-center w-screen h-auto">
            <h1 className="text-7xl font-mono font-bold">PERSONAJES</h1>
        </div>
    </div>
  );
}

export default Navbar;